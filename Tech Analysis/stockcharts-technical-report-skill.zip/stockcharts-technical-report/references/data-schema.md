# Data schema & how the engine works

The report is a **single self-contained HTML file**. All the visible content is generated at load time from one JavaScript array — `CHARTS` — plus the reusable `DEF`/`TITLE` glossary. You almost never touch the CSS or the engine functions; you replace the *data* and the *prose* (header, Executive Summary, Bottom Line) and everything else redraws itself.

Two example files ship with this skill in `assets/`:

- `example-single-list.html` — one ChartList, ~37 charts. Numbered `nbox`, optional page filter, and an optional inline **converter** widget. Use this shape for a single ChartList or a single theme (e.g. Breadth only).
- `example-multi-list.html` — five ChartLists merged, ~51 charts, grouped, with an embedded chart **image** per card. Use this shape when combining several lists into one dashboard.

Pick the closer example, copy it to the new report filename, then edit.

---

## Signal buckets (the core vocabulary)

Every chart is classified into exactly one of five signals. These drive the left border color of each card, the tag, the TOC dot, the stat-strip counts, and the signal filter.

| key | meaning | color var |
|-----|---------|-----------|
| `bull` | Bullish / constructive | green `--bull` |
| `ext`  | Bullish but **extended** / overbought — right trend, stretched | teal `--ext` |
| `caut` | Caution / watch — deteriorating or mixed with downside risk | amber `--caut` |
| `neut` | Neutral / mixed — no clear edge | grey `--neut` |
| `bear` | Bearish / downtrend | red `--bear` |

Keep the mapping honest: `ext` is for charts that are still in an uptrend but overextended (a nuance the reader values), not a synonym for `bull`.

---

## Variant A — single list (`example-single-list.html`)

```js
const CHARTS = [
  {n:"110", cat:"Trend", sig:"caut", title:"110 S&P 500 Daily",
   link:"https://stockcharts.com/c-sc/sc?s=%24SPX&p=D&...",
   // pg is OPTIONAL — only if the source spans multiple pages; drives the page filter
   pg:1,
   body:[
     "Signal: caution. The S&P 500 closed at 7,354.02, below the 21-day EMA near 7,418.26 ...",
     "This chart keeps the market in the repair zone. The first bullish repair would be ..."
   ]},
  // ...one object per chart
];
const CATS = ["Trend","Risk Appetite","Breadth","Macro & Rates","Commodities & Crypto","Volatility","Sentiment & Positioning","Sector Leadership"];
```

Fields: `n` number/badge (string), `cat` category (must appear in `CATS`), `sig` signal, `title`, `link` (StockCharts chart URL, opens in new tab), `body` array of paragraph strings, optional `pg`.

Filters built by `mkSelect(...)`: page (only if you use `pg`), signal, category. If the report is a single page, delete the `mkSelect("pg", …)` call and the `activePg` checks, or just omit `pg`.

**Optional converter widget:** `example-single-list.html` includes an inline units converter (SPX ⇄ an ETF that tracks it). It is self-contained in the `.conv` HTML block plus the trailing `XUS.U ⇄ SPX converter` IIFE. If the report doesn't need it, delete both. If you keep it, re-anchor it to a fresh same-day price pair.

---

## Variant B — multi list with images (`example-multi-list.html`)

```js
const G = {                         // group (ChartList) definitions
  idx:{label:"US Indexes"}, brd:{label:"Breadth"}, sen:{label:"Sentiment"},
  tac:{label:"Tactical Timing"}, sec:{label:"Sectors (Cap-Weight)"}
};
const GROUP_ORDER = ["idx","brd","sen","tac","sec"];
const IMG = "../Charts/Image/";     // relative path to the chart PNGs

const CHARTS = [
  {id:"idx01", g:"idx", nbox:"$COMPQ", cat:"Nasdaq Composite", sig:"caut",
   title:"$COMPQ — Nasdaq Composite",
   link:"https://stockcharts.com/c-sc/sc?s=%24COMPQ&...",
   img:IMG+"stockcharts-us-indexes-01-compq-nasdaq-composite.png",
   body:["Caution flag: ...","RSI(14) is near 49.00 ..."]},
  // ...
];
```

Differences from Variant A: `id` instead of `n`; `g` group key (drives the "All lists" group filter, built from `GROUP_ORDER`/`G`); `nbox` is a ticker shown in the badge; `img` embeds the chart PNG in the card body. The filter set is group + signal (no category dropdown), but `cat` is still shown as the card subtitle.

When embedding images, point `IMG` at the report's location relative to `Market/Tech Analysis/Charts/Image/` (from `Report/` that is `../Charts/Image/`). Confirm each PNG exists.

---

## The engine (don't rewrite these — reuse as-is)

All of the following already live in the example files and work generically off `CHARTS`:

- **Stat strip counts** — counts each `sig` bucket.
- **Card + TOC builder** — renders one expandable card and one TOC link per chart; cards are collapsed by default and color-coded by signal.
- **Filters** (`mkSelect`) + **search** — live filter by category/group/page/signal and free-text over title+body.
- **Scrollspy** — `IntersectionObserver` highlights the active TOC link.
- **Collapsible Executive Summary** — folded by default.
- **TA highlighter** (`hl` + `MASTER` regex) — wraps indicators, tickers, numbers/levels, and dates in colored tokens. Applied to summary, card bodies, and Bottom Line.
- **Glossary tooltips** (`DEF`/`TITLE` + `defKey` + the `#tip` popup) — hover/tap an underlined indicator for its definition.

### Extending the highlighter/glossary for a new term

1. Add `"term":"definition"` to `DEF` and `"term":"Nice Name"` to `TITLE` (in `ta-glossary.md`).
2. Add the surface spellings to the `MASTER` regex `ind` group so it gets matched and underlined.
3. If the on-page wording differs from the `DEF` key (plurals, slashes, hyphens), add a normalization rule in `defKey()`.

Tickers and price levels are matched automatically by the `sym` and `lvl`/`period` groups — usually no work needed, but if a new ticker must be recognized, add it to the `sym` alternation.
