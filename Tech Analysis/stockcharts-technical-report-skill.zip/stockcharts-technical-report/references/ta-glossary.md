# TA glossary (reusable)

The report auto-highlights technical terms in the Executive Summary, card bodies, and Bottom Line, and shows a hover/tap tooltip with a plain-English definition. That behavior is driven by two JS objects: `DEF` (the definition text) and `TITLE` (the nicely-formatted term name shown as the tooltip heading).

**Reuse this block verbatim** when building a new report — it already covers the indicators that show up in almost every StockCharts / Dave Keller ChartList. Only add entries when a chart introduces a term not already here (append to both `DEF` and `TITLE`, and, if the term needs fuzzy matching, add a rule inside `defKey()` and a token to the `MASTER` regex `ind` group — see `data-schema.md`).

Definitions are intentionally short (1–2 sentences), neutral, and educational — they explain what the term means and how traders read it, never giving advice.

```js
/* ---- Glossary of TA indicators (shown in popups) ---- */
const DEF = {
 "ema":"A moving average that weights recent prices more heavily, so it turns faster than a simple average. Traders watch whether price holds above or below it to read trend.",
 "moving average":"The average price over a set number of periods, smoothing out noise to show trend direction. Price above a rising average is bullish; below a falling one is bearish.",
 "cmf":"Chaikin Money Flow gauges buying vs. selling pressure by mixing where price closes in its range with volume. Above zero suggests accumulation; below zero, distribution.",
 "mcclellan oscillator":"A short-term breadth-momentum gauge built from advancing minus declining stocks. Above zero means broad buying momentum; below zero, broad selling.",
 "bullish percent index":"The percentage of stocks in an index on point-and-figure buy signals. Above 50 favors bulls; very high (70+) can be overbought, very low oversold.",
 "advance decline line":"A running total of advancing minus declining stocks. A rising line confirms broad participation behind an index move; a falling line warns breadth is narrowing.",
 "relative strength":"Compares one asset's performance against another (usually a benchmark). A rising ratio means it's outperforming; falling means lagging. Not the same as RSI.",
 "new highs new lows":"Counts of stocks hitting fresh 52-week highs vs. lows. Expanding new highs confirm a healthy rally; rising new lows beside a strong index warn of hidden weakness.",
 "yield curve":"The spread between long- and short-term Treasury yields. A positive (steep) curve is normal; a negative (inverted) curve has historically preceded recessions.",
 "bull bear spread":"Bullish survey responses minus bearish ones. Used as a contrarian gauge — extreme optimism can mark tops, extreme pessimism bottoms.",
 "naaim exposure index":"Measures how invested active managers are in equities, from heavily short to fully long. High readings show professionals are committed to the trend.",
 "move index":"The bond market's version of the VIX — it measures expected Treasury volatility. A rising MOVE signals rate-market stress that can spill into stocks.",
 "point and figure":"A charting method that ignores time and small wiggles, plotting only meaningful price moves as X's and O's to clarify support, resistance, and signals.",
 "high yield spread":"The extra yield investors demand to hold riskier 'junk' bonds over Treasuries. Widening spreads signal credit stress; tight spreads signal calm, risk-on conditions.",
 "higher highs":"A series of peaks each above the last (with troughs also rising) — the textbook definition of an uptrend. The opposite, lower lows, defines a downtrend.",
 "lower low":"A trough below the prior trough, a hallmark of a downtrend. A higher low instead suggests selling pressure is easing.",
 "overbought":"A condition (often RSI above 70) where price has risen far and fast, raising odds of a pause or pullback — though it can persist in strong trends.",
 "oversold":"A condition (often RSI below 30) where price has fallen far and fast, raising odds of a bounce — though it can persist in strong downtrends.",
 "uptrend":"A sustained rise of higher highs and higher lows. Trend-followers treat pullbacks as opportunities until that structure breaks.",
 "downtrend":"A sustained decline of lower highs and lower lows. Rallies are often treated as selling opportunities until the structure repairs.",
 "divergence":"When price and an indicator disagree — e.g. price makes a new high but momentum doesn't. It warns the move may be losing conviction.",
 "breakout":"When price pushes decisively through resistance, often starting a new advance. A breakdown is the same through support, to the downside.",
 "trendline":"A straight line connecting successive highs or lows. Holding the line supports the trend; a clean break can signal a change of direction.",
 "momentum":"The speed and strength of a price move. Strong momentum confirms a trend; fading momentum can precede a stall or reversal.",
 "accumulation":"Sustained buying that builds positions, often seen as rising volume on up days. The opposite of distribution.",
 "distribution":"Sustained selling into strength as larger holders trim positions. It can cap rallies even while price still looks firm.",
 "consolidation":"A sideways pause where price digests a prior move within a range. It often resolves in the direction of the preceding trend.",
 "risk on":"An environment where investors favor higher-risk assets (stocks, cyclicals, crypto). Risk-off is the flight to safety (cash, bonds, defensives).",
 "retracement":"A partial pullback against the prevailing trend, often measured with Fibonacci levels (38.2%, 50%, 61.8%) to find likely support or resistance.",
 "support":"A price area where buying has previously halted declines. Holding support keeps a trend intact; losing it opens lower levels.",
 "resistance":"A price area where selling has previously capped advances. Clearing resistance is bullish; failing there can stall a rally.",
 "rsi":"Relative Strength Index — a 0–100 momentum oscillator. Above 70 is overbought, below 30 oversold; the 50 midline splits bullish from bearish momentum.",
 "macd":"Moving Average Convergence Divergence — tracks the gap between two EMAs to show trend and momentum. Crosses of its signal line flag shifts.",
 "ppo":"Percentage Price Oscillator — like MACD but in percent, so momentum can be compared across different securities. Above zero is bullish momentum.",
 "fibonacci":"Retracement levels (23.6%, 38.2%, 50%, 61.8%) drawn from the Fibonacci sequence, used to estimate where a pullback may find support or resistance.",
 "coppock curve":"A long-term momentum indicator (a smoothed sum of rate-of-change), used mainly on monthly charts. A turn up from below zero has historically flagged durable market bottoms.",
 "high beta":"High-beta stocks swing more than the market (beta above 1). When high beta leads low-volatility stocks, it signals strong risk appetite (risk-on).",
 "low volatility":"Low-volatility stocks move less than the market and are defensive. Leadership by low-vol over high-beta signals caution and risk-off positioning.",
 "signal line":"A moving average of an oscillator like MACD or PPO. The oscillator crossing above its signal line is bullish momentum; crossing below is bearish.",
 "histogram":"The bars showing the gap between an oscillator (MACD/PPO) and its signal line. Growing bars mean strengthening momentum; shrinking bars, fading momentum."
};
const TITLE = {
 "ema":"Exponential Moving Average (EMA)","moving average":"Moving Average","cmf":"Chaikin Money Flow (CMF)",
 "mcclellan oscillator":"McClellan Oscillator","bullish percent index":"Bullish Percent Index","advance decline line":"Advance-Decline Line",
 "relative strength":"Relative Strength","new highs new lows":"New Highs / New Lows","yield curve":"Yield Curve",
 "bull bear spread":"Bull-Bear Spread","naaim exposure index":"NAAIM Exposure Index","move index":"MOVE Index",
 "point and figure":"Point-and-Figure","high yield spread":"High-Yield Spread","higher highs":"Higher Highs / Higher Lows",
 "lower low":"Lower Low","overbought":"Overbought","oversold":"Oversold","uptrend":"Uptrend","downtrend":"Downtrend",
 "divergence":"Divergence","breakout":"Breakout / Breakdown","trendline":"Trendline","momentum":"Momentum",
 "accumulation":"Accumulation","distribution":"Distribution","consolidation":"Consolidation","risk on":"Risk-On / Risk-Off",
 "retracement":"Retracement","support":"Support","resistance":"Resistance","rsi":"Relative Strength Index (RSI)",
 "macd":"MACD","ppo":"Percentage Price Oscillator (PPO)","fibonacci":"Fibonacci Retracement",
 "coppock curve":"Coppock Curve","high beta":"High Beta","low volatility":"Low Volatility",
 "signal line":"Signal Line","histogram":"Histogram"
};
```
