---
name: stockcharts-technical-report
description: Build Sam's stock-chart / market technical-analysis report as a single self-contained HTML page. Default to the concise "Quick Dashboard" style Sam prefers (a verdict banner, a Defense⇄Offense-style bar gauge, compact stat tiles with a big number + mini bar + one plain-English line each, and a short "what would change the picture" panel) — NOT walls of text. A wordier signature variant (filterable signal cards, collapsible executive summary, glossary tooltips) is still available when explicitly asked for detail. Use this whenever building or refreshing a technical/chart analysis report from a StockCharts ChartList or Dave Keller "Market Misbehavior" markdown, a multi-chart breadth/sentiment/sector/timing review, or any request like "analyze this ChartList", "study these charts", "make the StockCharts report", "turn these chart notes into the usual page", or refreshing an existing report in Market/Tech Analysis/Report/. Produces one HTML file saved to Market/Tech Analysis/Report/ with a card added to the root index.html.
---

# StockCharts interactive technical report

This skill reproduces the interactive technical-analysis report Sam uses in the Hobby project (`Market/Tech Analysis/Report/`). The design and engine are already solved and proven — your job is to **populate them with correct, well-classified chart analysis**, not to redesign anything. Cloning a working example and swapping the data is deliberate: it guarantees the look, the interactivity, and the glossary all keep working.

## ⭐ Default style: the concise "Quick Dashboard"

**Sam's stated preference (2026-07): keep these reports visual and scannable, not wordy.** Long prose "makes him confused." Unless he explicitly asks for the detailed/deep version, build the **Quick Dashboard** variant:

- Clone **`assets/example-quick-dashboard.html`** and swap its `DATA` array + verdict text.
- Structure, top → bottom: (1) slim header; (2) **verdict banner** — an uppercase "one-line read" eyebrow, a big headline (e.g. "Risk-on — but narrowing"), one short sentence, and a simple tally/score box; (3) **hero bar gauge** — one row per item, a track with a center zero line, a colored fill + dot for the current value, and a faint "peak" tick for the 1-yr high; (4) **compact stat tiles** (2-col grid) — one per item: ticker, plain name, a colored signal chip, a BIG number, a mini gauge bar, and exactly ONE plain-English sentence; (5) optional **benchmark tile** (the index itself); (6) **"what would change the picture"** — two short bullet lists (✅ / 🛑), max 3 bullets each.
- **Hard rules:** plain language not jargon ("everyday staples now beat 'want' spending," not "discretionary/staples relative strength rolled over"); ONE sentence per item; no long collapsible executive summary; no dense glossary/tooltip prose; render tiles + bars from a small JS `DATA` array so numbers and bars stay in sync.
- Keep the shared `:root` token set and signal colors (bull=green, ext=teal "leading·cooling", caut=amber "gone defensive", neut=grey, bear=red), the header disclaimer, and the save-to-`Report/` + index-card steps below.

Use the wordier signature variant (next sections) only when Sam explicitly wants the deep, filterable, fully-annotated version.

## What the report is

A single self-contained HTML file (no build step, no external JS except the linked-out StockCharts chart URLs). Everything renders from one `CHARTS` data array plus a reusable TA glossary. Signature elements, top to bottom:

- **Navy gradient header** — title, one-line source/date/count subtitle, meta chips, and the disclaimer "technical chart interpretation only, not investment advice."
- **Stat strip** — five cards counting the signal buckets (Bullish / Bullish·Extended / Neutral / Caution / Bearish).
- **Executive Summary** — collapsible, folded by default; regime read, leadership, cross-asset, key conclusion/thesis, and a numbered "highest-conviction conclusions" list.
- **Sticky controls** — free-text search + dropdown filters (category or list-group, signal, optionally page) + a color-key legend.
- **Two-column body** — a scrollspy table of contents on the left; expandable, signal-color-coded chart cards on the right. Each card: number/ticker badge, title, category, signal tag, and a body of 1–2 short paragraphs with an "Open chart on StockCharts" link (and an embedded PNG in the multi-list variant).
- **Bottom Line** — dark panel: net read, monitoring checklist, and two watch-lists ("bullish repair signals" ✅ / "bearish confirmation" 🛑).
- **Live TA highlighting** — indicators, tickers, price levels, and dates are auto-colored; underlined indicators show a plain-English tooltip on hover/tap.

## When to reach for each example

Three working files ship in `assets/` — copy the closer one, don't start from scratch:

- **`assets/example-quick-dashboard.html`** — ⭐ **the default.** Concise, visual, low-word dashboard (verdict banner + hero bar gauge + compact stat tiles + "what would change the picture"). Data-driven from a small `DATA` array. Use this for almost every request unless Sam asks for the detailed version.
- **`assets/example-single-list.html`** — the wordier signature variant for one ChartList: filterable numbered cards, collapsible executive summary, glossary tooltips, scrollspy TOC. Use only when Sam wants depth.
- **`assets/example-multi-list.html`** — the wordier variant for several ChartLists merged into one dashboard, grouped, with a chart PNG embedded in each card.

Read `references/data-schema.md` for the exact field-by-field schema of both variants and how the engine works. Read `references/ta-glossary.md` for the reusable `DEF`/`TITLE` glossary block to paste in.

## Build workflow

1. **Gather the raw material.** Source is usually a dated markdown file in `Market/Tech Analysis/Charts/md file/` (e.g. `Dave_Keller_Market_Misbehavior_ChartList_Analysis_YYYY-MM-DD.md`) or a StockCharts ChartList the user points at. If working from live charts, capture each chart's key readings (price vs. moving averages, RSI/PPO/MACD, breadth/ratio levels). Don't invent numbers — every level in the text should trace to the source.

2. **Classify each chart** into one signal bucket (`bull` / `ext` / `caut` / `neut` / `bear`). Be disciplined: `ext` means still-bullish-but-overextended, `caut` means downside risk building. This classification is the backbone of the whole report.

3. **Clone the closer example** to the new report filename (see Naming) and replace, in order:
   - Header: title, subtitle (source · date · chart count · one-line net read), meta chips, keep the disclaimer.
   - The `CHARTS` array: one object per chart with `title`, `cat`/group, `sig`, `link`, and a `body` of 1–2 tight paragraphs. Lead each body with "Signal: …" then the evidence, then what would confirm/repair it.
   - `CATS` (or the group `G`/`GROUP_ORDER`) to match your categories.
   - Executive Summary and Bottom Line prose.
   - Confirm the glossary (`DEF`/`TITLE`) covers every indicator you mention; add any missing ones per `references/data-schema.md`.

4. **Leave the CSS and engine functions untouched** — the stat counts, filters, scrollspy, highlighter, and tooltips all work generically off `CHARTS`. If you change the *shape* of the data, follow the schema reference so the engine keeps matching.

5. **Save to `Market/Tech Analysis/Report/`** and **add a linking card to the root `index.html`** under the 金融市场 (Financial Markets) section — matching the existing StockCharts cards. (The Tech Analysis folder's own `CLAUDE.md` documents this: `.md` research in → `Charts/md file/`, final report out → `Report/`.)

6. **Verify before delivering** — open the file and check: the stat-strip numbers equal the count in each signal bucket, every card expands, filters and search narrow the list, TOC scrollspy tracks, at least a few indicator tooltips fire, and every `link`/`img` resolves. Then present the file.

## Content & voice conventions

- **Educational, neutral, not advisory.** Describe what the charts show and what would confirm or invalidate a read. Never "buy/sell." Always keep the header disclaimer.
- **Paragraphs, not bullets, inside card bodies** — 1–2 sentences each, concrete levels, then the trigger that would change the read.
- **Numbers stay faithful to the source.** The highlighter will style them; your job is accuracy.
- **English content** for these reports (matches the existing files), even though other Market pages are bilingual.

## Naming

Match the existing pattern in `Report/`: `stockcharts-<scope>-analysis.html` (e.g. `stockcharts-breadth-listnum10-analysis.html`, `stockcharts-page-1-analysis.html`) or `stockcharts-combined-technical-analysis.html` for a merged dashboard. Prefer a dated or list-scoped, descriptive slug.
